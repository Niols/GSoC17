var searchData=
[
  ['errors',['errors',['../structspot_1_1parsed__aut.html#a444e53e64b16042f874a64476f38ad93',1,'spot::parsed_aut::errors()'],['../structspot_1_1parsed__formula.html#a7434f0c64850c13b4976b34b1c27949e',1,'spot::parsed_formula::errors()']]]
];
