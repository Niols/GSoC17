var searchData=
[
  ['algorithm_20patterns',['Algorithm patterns',['../group__ta__generic.html',1,'']]],
  ['algorithm_20patterns',['Algorithm patterns',['../group__twa__generic.html',1,'']]]
];
