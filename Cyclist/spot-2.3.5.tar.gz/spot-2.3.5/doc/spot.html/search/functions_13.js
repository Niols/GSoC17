var searchData=
[
  ['u',['U',['../classspot_1_1formula.html#a35c4334f1dd6b5448c009b94b403bfbe',1,'spot::formula::U(const formula &amp;f, const formula &amp;g)'],['../classspot_1_1formula.html#a2e64b39eb06fb28b067fc6b9857f08da',1,'spot::formula::U(const formula &amp;f, formula &amp;&amp;g)'],['../classspot_1_1formula.html#a0fa1d0aed98505b0c33f4ca5adf831ab',1,'spot::formula::U(formula &amp;&amp;f, const formula &amp;g)'],['../classspot_1_1formula.html#a7ce32445949d1e633cba5b4b2bd706c4',1,'spot::formula::U(formula &amp;&amp;f, formula &amp;&amp;g)']]],
  ['uconcat',['UConcat',['../classspot_1_1formula.html#a4b909bf6b451e28df9e7d3e8305578a1',1,'spot::formula::UConcat(const formula &amp;f, const formula &amp;g)'],['../classspot_1_1formula.html#a7c3d213444118ee9d3a401eabd73383b',1,'spot::formula::UConcat(const formula &amp;f, formula &amp;&amp;g)'],['../classspot_1_1formula.html#aad6b4c5d2d991d781c9cdcd2c7f22932',1,'spot::formula::UConcat(formula &amp;&amp;f, const formula &amp;g)'],['../classspot_1_1formula.html#a36e20c8209f4fcd1f7f375d34e1b2998',1,'spot::formula::UConcat(formula &amp;&amp;f, formula &amp;&amp;g)']]],
  ['unabbreviate',['unabbreviate',['../group__tl__rewriting.html#gafc353f999ab1bab155def38d1a2b4c04',1,'spot']]],
  ['unabbreviator',['unabbreviator',['../classspot_1_1unabbreviator.html#a4a75cc9ceb9d31893a3d616f4b106c37',1,'spot::unabbreviator']]],
  ['unbounded',['unbounded',['../classspot_1_1fnode.html#a293c84605153e8e773bd3cc056846ba6',1,'spot::fnode::unbounded()'],['../classspot_1_1formula.html#a568cccf8ab356e4fc1bf51d0dfde3ed4',1,'spot::formula::unbounded()']]],
  ['unop',['unop',['../classspot_1_1fnode.html#ab4afcc96178e76986d085620f750c3c1',1,'spot::fnode::unop()'],['../classspot_1_1formula.html#af929523d6cae3203d20616bd8b1bdf6e',1,'spot::formula::unop(op o, const formula &amp;f)'],['../classspot_1_1formula.html#a6076a523eccc53cc40bf121a6ed8121d',1,'spot::formula::unop(op o, formula &amp;&amp;f)']]],
  ['unregister_5fall_5fmy_5fvariables',['unregister_all_my_variables',['../classspot_1_1bdd__dict.html#a64b9d9dcc789312a700519388faf40e8',1,'spot::bdd_dict']]],
  ['unregister_5fap',['unregister_ap',['../classspot_1_1twa.html#aa894cadf4f669d8dbf713e6d61795630',1,'spot::twa']]],
  ['unregister_5fvariable',['unregister_variable',['../classspot_1_1bdd__dict.html#aa502521a61d81107e8c7ce5fab09ed7c',1,'spot::bdd_dict::unregister_variable(int var, const void *me)'],['../classspot_1_1bdd__dict.html#a5ea0b8ca41d9c4a72d8de94575050af6',1,'spot::bdd_dict::unregister_variable(int var, std::shared_ptr&lt; T &gt; me)']]],
  ['used_5facc',['used_acc',['../classspot_1_1scc__info.html#a528ec0c795d98aa85f000513e635c81f',1,'spot::scc_info']]],
  ['utime',['utime',['../classspot_1_1timer.html#ab430ec9ff884438199794f4c8daefc78',1,'spot::timer']]]
];
