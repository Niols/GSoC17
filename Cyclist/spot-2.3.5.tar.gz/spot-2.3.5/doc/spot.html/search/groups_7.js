var searchData=
[
  ['ta_20_28testing_20automata_29',['TA (Testing Automata)',['../group__ta.html',1,'']]],
  ['ta_20algorithms',['TA algorithms',['../group__ta__algorithms.html',1,'']]],
  ['ta_20simplifications',['TA simplifications',['../group__ta__reduction.html',1,'']]],
  ['ta_20representations',['TA representations',['../group__ta__representation.html',1,'']]],
  ['transforming_20tgba_20into_20ta',['Transforming TGBA into TA',['../group__tgba__ta.html',1,'']]],
  ['temporal_20logic',['Temporal Logic',['../group__tl.html',1,'']]],
  ['tωa_20_28transition_2dbased_20ω_2dautomata_29',['TωA (Transition-based ω-Automata)',['../group__twa.html',1,'']]],
  ['tωa_20algorithms',['TωA algorithms',['../group__twa__algorithms.html',1,'']]],
  ['translating_20ltl_20formulas_20into_20tωa',['Translating LTL formulas into TωA',['../group__twa__ltl.html',1,'']]],
  ['tωa_20on_2dthe_2dfly_20algorithms',['TωA on-the-fly algorithms',['../group__twa__on__the__fly__algorithms.html',1,'']]],
  ['tωa_20simplifications',['TωA simplifications',['../group__twa__reduction.html',1,'']]],
  ['tωa_20representations',['TωA representations',['../group__twa__representation.html',1,'']]],
  ['tωa_20runs_20and_20supporting_20functions',['TωA runs and supporting functions',['../group__twa__run.html',1,'']]]
];
