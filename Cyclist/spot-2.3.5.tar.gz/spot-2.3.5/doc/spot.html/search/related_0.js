var searchData=
[
  ['make_5fbitvect',['make_bitvect',['../classspot_1_1bitvect.html#a086c21dc0b76db27d956db51351e61da',1,'spot::bitvect']]],
  ['make_5fbitvect_5farray',['make_bitvect_array',['../classspot_1_1bitvect.html#a4b9e54a150a91d7b8ddbdebb732134a0',1,'spot::bitvect::make_bitvect_array()'],['../classspot_1_1bitvect__array.html#a4b9e54a150a91d7b8ddbdebb732134a0',1,'spot::bitvect_array::make_bitvect_array()']]]
];
