var searchData=
[
  ['identity_5fhash',['identity_hash',['../structspot_1_1identity__hash.html',1,'spot']]],
  ['isomorphism_5fchecker',['isomorphism_checker',['../classspot_1_1isomorphism__checker.html',1,'spot']]]
];
