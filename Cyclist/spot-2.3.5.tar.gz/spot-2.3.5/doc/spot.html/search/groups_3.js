var searchData=
[
  ['input_2foutput_20of_20ta',['Input/Output of TA',['../group__ta__io.html',1,'']]],
  ['input_20and_20output_20of_20formulas',['Input and Output of Formulas',['../group__tl__io.html',1,'']]],
  ['input_2foutput_20of_20tωa',['Input/Output of TωA',['../group__twa__io.html',1,'']]]
];
