var searchData=
[
  ['version',['version',['../group__misc__tools.html#ga85c83eb1d18703782d129dbe4a518fca',1,'spot']]]
];
