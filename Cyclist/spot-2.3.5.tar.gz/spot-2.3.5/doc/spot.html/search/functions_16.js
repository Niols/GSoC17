var searchData=
[
  ['x',['X',['../classspot_1_1formula.html#a48b3bf58299703b00dffd64f64d5d3d5',1,'spot::formula::X(const formula &amp;f)'],['../classspot_1_1formula.html#a66df3a2dcbe10a68cd276eb02bdf5d71',1,'spot::formula::X(formula &amp;&amp;f)']]],
  ['xor',['Xor',['../classspot_1_1formula.html#a01a38bdfd89a2d654e42061076f2c9d7',1,'spot::formula::Xor(const formula &amp;f, const formula &amp;g)'],['../classspot_1_1formula.html#a0ac7e4ca73e43973898b3e69e3dd8fcc',1,'spot::formula::Xor(const formula &amp;f, formula &amp;&amp;g)'],['../classspot_1_1formula.html#a38e9a406b6a5d662504b46d02666dcdf',1,'spot::formula::Xor(formula &amp;&amp;f, const formula &amp;g)'],['../classspot_1_1formula.html#a12bda8ec8752616d027f0fddd625c3e6',1,'spot::formula::Xor(formula &amp;&amp;f, formula &amp;&amp;g)']]]
];
