var searchData=
[
  ['closure',['Closure',['../group__tl__essentials.html#gga770300a8f53109afba0868269371e442aaf4bb376939e77df0e7c2332b837a866',1,'spot']]],
  ['concat',['Concat',['../group__tl__essentials.html#gga770300a8f53109afba0868269371e442ae20f0f2826a6549809f050b86274567f',1,'spot']]]
];
