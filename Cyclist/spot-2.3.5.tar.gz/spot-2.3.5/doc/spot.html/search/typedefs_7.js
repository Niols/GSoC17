var searchData=
[
  ['ref_5fset',['ref_set',['../classspot_1_1bdd__dict.html#a015d330da101dd646875b8ed1613a2d6',1,'spot::bdd_dict']]]
];
