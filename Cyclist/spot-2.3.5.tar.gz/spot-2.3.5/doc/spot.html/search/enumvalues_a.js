var searchData=
[
  ['star',['Star',['../group__tl__essentials.html#gga770300a8f53109afba0868269371e442a26f93e6e68e28a698377e941cb59f29a',1,'spot']]]
];
