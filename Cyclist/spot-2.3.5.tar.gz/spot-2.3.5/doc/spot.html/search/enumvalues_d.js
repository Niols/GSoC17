var searchData=
[
  ['w',['W',['../group__tl__essentials.html#gga770300a8f53109afba0868269371e442a61e9c06ea9a85a5088a499df6458d276',1,'spot']]]
];
