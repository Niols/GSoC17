var indexSectionsWithContent =
{
  0: "abcdefghiklmnopqrstuvwx~",
  1: "abcdefhiklmnoprstu",
  2: "fp",
  3: "abcdefghiklmnopqrstuvwx~",
  4: "acdefgikloprstvw",
  5: "adfkloprstv",
  6: "o",
  7: "acefgimnorstuwx",
  8: "mo",
  9: "aehikmrt",
  10: "bs"
};

var indexSectionNames =
{
  0: "all",
  1: "classes",
  2: "files",
  3: "functions",
  4: "variables",
  5: "typedefs",
  6: "enums",
  7: "enumvalues",
  8: "related",
  9: "groups",
  10: "pages"
};

var indexSectionLabels =
{
  0: "All",
  1: "Classes",
  2: "Files",
  3: "Functions",
  4: "Variables",
  5: "Typedefs",
  6: "Enumerations",
  7: "Enumerator",
  8: "Friends",
  9: "Modules",
  10: "Pages"
};

