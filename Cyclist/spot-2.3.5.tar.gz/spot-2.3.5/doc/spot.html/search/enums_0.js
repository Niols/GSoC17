var searchData=
[
  ['op',['op',['../group__tl__essentials.html#ga770300a8f53109afba0868269371e442',1,'spot']]]
];
