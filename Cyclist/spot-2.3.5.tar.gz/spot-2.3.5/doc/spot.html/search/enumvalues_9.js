var searchData=
[
  ['r',['R',['../group__tl__essentials.html#gga770300a8f53109afba0868269371e442ae1e1d3d40573127e9ee0480caf1283d6',1,'spot']]]
];
