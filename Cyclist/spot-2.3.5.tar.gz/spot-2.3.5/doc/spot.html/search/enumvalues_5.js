var searchData=
[
  ['implies',['Implies',['../group__tl__essentials.html#gga770300a8f53109afba0868269371e442aef634d4bb5af5448f6c1d9c786ab63fe',1,'spot']]]
];
