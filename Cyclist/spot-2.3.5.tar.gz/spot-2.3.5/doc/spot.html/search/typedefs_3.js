var searchData=
[
  ['kind_5ftype',['kind_type',['../structhoayy_1_1parser_1_1by__type.html#a22572fd13e1e44f55e438cba1433bd87',1,'hoayy::parser::by_type::kind_type()'],['../structtlyy_1_1parser_1_1by__type.html#a502abfa5aa71f12aad47a02e5fde0cdc',1,'tlyy::parser::by_type::kind_type()']]]
];
