var searchData=
[
  ['negclosure',['NegClosure',['../group__tl__essentials.html#gga770300a8f53109afba0868269371e442a49b896944db944beb13a670a7b626824',1,'spot']]],
  ['negclosuremarked',['NegClosureMarked',['../group__tl__essentials.html#gga770300a8f53109afba0868269371e442a6d8ef00a66fa645c3788efa3cab843a5',1,'spot']]],
  ['not',['Not',['../group__tl__essentials.html#gga770300a8f53109afba0868269371e442aa74c05d080620f087c4e523977230666',1,'spot']]]
];
