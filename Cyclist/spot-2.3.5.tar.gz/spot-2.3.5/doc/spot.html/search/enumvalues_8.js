var searchData=
[
  ['or',['Or',['../group__tl__essentials.html#gga770300a8f53109afba0868269371e442a3a2d5fe857d8f9541136a124c2edec6c',1,'spot']]],
  ['orrat',['OrRat',['../group__tl__essentials.html#gga770300a8f53109afba0868269371e442a9284c10af2accfe937ea66f1af92f97e',1,'spot']]]
];
