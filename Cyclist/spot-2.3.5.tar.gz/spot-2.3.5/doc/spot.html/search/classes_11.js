var searchData=
[
  ['unabbreviator',['unabbreviator',['../classspot_1_1unabbreviator.html',1,'spot']]],
  ['univ_5fdest_5fmapper',['univ_dest_mapper',['../classspot_1_1internal_1_1univ__dest__mapper.html',1,'spot::internal']]],
  ['unsigned_5fstatistics',['unsigned_statistics',['../structspot_1_1unsigned__statistics.html',1,'spot']]],
  ['unsigned_5fstatistics_5fcopy',['unsigned_statistics_copy',['../classspot_1_1unsigned__statistics__copy.html',1,'spot']]]
];
