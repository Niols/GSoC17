var searchData=
[
  ['named_5fgraph',['named_graph',['../classspot_1_1named__graph.html',1,'spot']]]
];
