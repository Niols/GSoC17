var searchData=
[
  ['x',['X',['../group__tl__essentials.html#gga770300a8f53109afba0868269371e442a02129bb861061d1a052c592e2dc6b383',1,'spot']]],
  ['xor',['Xor',['../group__tl__essentials.html#gga770300a8f53109afba0868269371e442a76feb79109026728a20736a8c6504548',1,'spot']]]
];
