var searchData=
[
  ['quote_5fshell_5fstring',['quote_shell_string',['../group__misc__tools.html#gaad8c0d04c0c1647677756e5ee20cf8f0',1,'spot']]],
  ['quote_5funless_5fbare_5fword',['quote_unless_bare_word',['../group__misc__tools.html#ga4731f21b7b43332b5c7b5bc63c6d67e6',1,'spot']]]
];
