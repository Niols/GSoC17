var searchData=
[
  ['miscellaneous_20helper_20functions',['Miscellaneous helper functions',['../group__misc__tools.html',1,'']]],
  ['miscellaneous_20algorithms_20on_20ta',['Miscellaneous algorithms on TA',['../group__ta__misc.html',1,'']]],
  ['miscellaneous_20algorithms_20for_20formulas',['Miscellaneous Algorithms for Formulas',['../group__tl__misc.html',1,'']]],
  ['miscellaneous_20algorithms_20on_20tωa',['Miscellaneous algorithms on TωA',['../group__twa__misc.html',1,'']]]
];
